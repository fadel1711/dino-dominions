DINO DOMINION - IPHONE PLAYTEST

This is a touch-optimized HTML5 adaptation of the Alpha 0.2 browser game, not the Unity 3D Alpha 0.3 build. It runs offline after loading when hosted and cached, but save data is browser-specific.

IPHONE-ONLY HOSTING: Create a GitHub account, create a public repository, upload index.html through github.com in Safari (Request Desktop Website if needed), go to repository Settings > Pages, deploy from main branch / root, and wait for the GitHub Pages URL. Visit the URL in Safari and use Share > Add to Home Screen. Public repository means code is public.

Opening local HTML directly from iOS Files may not execute JavaScript; hosting is the recommended method.

Game has 3v3 RPG battles, dinosaur collection, simulated territories, base upgrades, events, and simulated alliances. No real multiplayer or 3D assets.
